<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="admin.php"><i class="menu-icon fa fa-laptop"></i>Dashboard</a>
                    </li>
					<li>
                        <a  href="enquiry.php"><i class="menu-icon fa fa-envelope-open-o"></i>Enquiry</a>
                    </li>
					<li>
                        <a href="viewstudent.php"><i class="menu-icon fa fa-user"></i>Student Registered</a>
                    </li>
					<!--<li>
                        <a href="testseries.php"><i class="menu-icon fa fa-user"></i>Test Series</a>
                    </li>-->
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-cogs"></i>Test Setting</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-cog"></i><a href="addtest.php">Add Test</a> </li>
                            <li><i class="menu-icon fa fa-cog"></i><a href="addques.php">Add Ques</a></li>
                            <li><i class="menu-icon fa fa-cog"></i><a href="queslist.php">Ques List</a></li>
                            <li><i class="menu-icon fa fa-cog"></i><a href="addconduct.php">Conduct Test</a></li>
                            
                            
                        </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-cogs"></i>Website Setting </a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-cog"></i><a href="carousel.php">Carousel</a> </li>
                            <li><i class="menu-icon fa fa-cog"></i><a href="addnews.php">News and Feed</a></li>
                            <li><i class="menu-icon fa fa-cog"></i><a href="addresult.php">Result</a></li>
                            <li><i class="menu-icon fa fa-cog"></i><a href="addtestimonial.php">Testimonial</a></li>
                            
                        </ul>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>