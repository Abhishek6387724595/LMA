<footer>
            <div class="col-md-8 footer-about">
                <h4><p> © 2020 La Militaire Academy. All rights reserved | Developed by<a href="#"> Snorweb</a>
          </p></h4>
               
            </div>
        
    </footer>